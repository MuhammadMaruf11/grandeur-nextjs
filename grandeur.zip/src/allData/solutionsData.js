export const solutionsData = [
    {
        icon: '/img/icons/WiFi Solutions for Labor Camps.webp',
        title: 'WiFi Solutions for Labor Camps',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/A2P SMS Solutions.webp',
        title: 'A2P SMS Solutions',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/Software Development.webp',
        title: 'Software Development',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
]