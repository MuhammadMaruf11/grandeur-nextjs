export const servicesData = [
    {
        icon:'/img/icons/billing-software.webp',
        title: 'Billing Software',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '/Security',
    },
    {
        icon: '/img/icons/wholesale-mobile-and-laptop.webp',
        title: 'Wholesale Mobile & Laptop',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/wifi-hotspot.webp',
        title: 'WiFi Hotspot',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/computer-systems-and-equipment-software-trading.webp',
        title: 'Compouter Systems & Communication Equipment Software Trading',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/computer-&-data-processing-requisites-trading.webp',
        title: 'Computer & Data Processing Requisites Trading',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/mobile-phone-and-accessories-trading.webp',
        title: 'Mobile Phones & Accessories Trading',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/it-infrastructure.webp',
        title: 'IT Infrastructure',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/internet-service.webp',
        title: 'Internet Services',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/cloud service and datacenters provider.webp',
        title: 'Cloud Services & Datacenters providers',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
    {
        icon: '/img/icons/information-technology-network-services.webp',
        title: 'Information Technology Network services',
        description: 'Thorough examination and evaluation of web applications to identify vulnerabilities and strengthen security measures.',
        url: '',
    },
]