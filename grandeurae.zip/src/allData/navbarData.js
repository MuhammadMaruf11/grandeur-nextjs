export const navbarData = [
    {
        title: 'Home',
        url : '/',
    },
    {
        title: 'About Us',
        url : '/about',
    },
    {
        title: 'Our Services',
        url : '/services',
    },
    {
        title: 'Network Solutions',
        url : '/solutions',
    },
    {
        title: 'Contact Us',
        url : '/contact',
    },
]